from Lesson_12_Working_with_files.Homework_12_Working_with_files.Homework_12_Phonebook_application.Components.working_with_files.open_read_file import \
    open_read_file


def load_user(filename):
    return open_read_file(filename)
