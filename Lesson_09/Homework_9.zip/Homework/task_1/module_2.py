import module_1 as md_1
from module_1 import module_1_function

md_1.module_1_function()

module_1_function()
