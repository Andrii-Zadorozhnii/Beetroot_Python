
def module_1_function():
    print(
        'Gratings'
    )